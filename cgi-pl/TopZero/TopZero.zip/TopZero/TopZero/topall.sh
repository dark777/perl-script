/usr/bin/perl /home/virtual/www/warezplaza/cgi-bin/topreport.cgi


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<META content="MSHTML 5.50.4522.1800" name=GENERATOR></HEAD>
<BODY><XMP>#!/usr/bin/perl
print "Content-type:text/html\n\n";
print "basedir = $ENV{DOCUMENT_ROOT}<br>";
print "BaseURL = http://$ENV{HTTP_HOST}";</XMP></BODY></HTML>

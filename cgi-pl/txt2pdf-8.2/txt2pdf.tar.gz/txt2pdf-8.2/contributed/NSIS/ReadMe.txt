We use NSIS http://www.nullsoft.com/free/nsis/ to create the Windows
Self Extracting EXE distribution.
In this directory you can find the txt2pdf.nsi configuration file we use. 

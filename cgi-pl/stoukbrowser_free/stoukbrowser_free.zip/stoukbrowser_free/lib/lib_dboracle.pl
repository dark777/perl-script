# Oracle database Handling Library

1;